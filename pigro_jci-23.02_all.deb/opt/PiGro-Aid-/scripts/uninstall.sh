#!/bin/bash

sudo rm -r $HOME/PiGro-Aid-/
sudo rm /usr/local/bin/pigro
sudo rm  /usr/share/applications/pigro.desktop
