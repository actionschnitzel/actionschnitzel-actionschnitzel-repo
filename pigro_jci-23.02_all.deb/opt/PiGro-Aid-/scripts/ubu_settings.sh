#This is a temporary solution... seems like at the moment python is nit able to call wayland windows -.- 
Preferences
