#!/bin/bash

python3 /opt/PiGro-Aid-/src/pigro_main.py


#Needs to be implemented
#sudo $(python3 ~/PiGro-Aid-/pigro_main.py)
#pkexec $(python3 ~/PiGro-Aid-/pigro_main.py)
