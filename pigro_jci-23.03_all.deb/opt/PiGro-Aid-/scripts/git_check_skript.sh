#!/bin/sh
cd ~/PiGro-Aid-

git remote update
git status -uno